# Book Annotator PWA — Next Session Opener
## (Paste this entire document at the start of the next session)

---

## Files to upload
1. **`index.html`** — current build
2. **`feature_tracker_updated.xlsx`** — tracker with all current updates
3. **This file** — the opener

**First thing to do:** read all three files fully before any code changes.

---

## Session rules (read every session)

- **No coding explanations** — just make the change and confirm what shipped. No narrating what you're doing, why, or what the problem was. Ever.
- **Keep responses simple.** The user is non-technical. Plain language only.
- **Label every request and fix with a `#` ticket number.** When the user reports a bug or new request, immediately assign it the next available `#` (e.g. `#271`, `#272`) and use that label everywhere — in chat, in the tracker, in the testing doc. This makes it easy to reference later.
- **🚨 IMPORTANT — TICKET NUMBER RECONCILIATION:** If the user is pasting in items from the in-app bug tracker, the # numbers from the app **will conflict** with the xlsx tracker. **The xlsx is the source of truth.** For each item the user pastes in:
  - **TEST RESULTS section** (`✅ #X works` / `⚠️ #X needs fixes`) — the # is an existing xlsx ticket. Do NOT renumber. Find that row, update the test status / notes.
  - **NEW REQUESTS section** — the app # is essentially scratch. Check first whether the request relates to an existing xlsx ticket: if yes, slot it under that ticket as a child / variant (use the parent request # column). If no, assign the **next available xlsx #** (e.g. if xlsx max is 273 and the app says #12, the new ticket becomes #274). Add a note in the xlsx like `(previously logged in app as #12)` so the trail is preserved.
  - The user has given explicit permission to renumber app-tracker #s when adding to xlsx.
- **Batch new requests by code locality** — slot them into whichever existing batch makes the most sense. Immediate/blocking fixes go into the very next batch.
- **One xlsx update per session, at the end of a completed batch.** Never mid-session, never mid-batch.
- **Syntax-check after every batch** before shipping: extract `<script>` block to `/tmp/app.js`, run `node --check /tmp/app.js`.
- **Don't ship half-finished work.** If tool budget runs low mid-feature, leave `/home/claude/index.html` untouched.
- **Search and read before changing.** Cross-references are heavy.
- **Stay in one code region per batch when possible.**
- **When testing feedback comes in:** categorize fixes as "next batch" (small/same region) or "future batch" (more effort). Never explain the bug. Just confirm what shipped and list what's queued.
- **Ship code first, narrate last.** Don't burn budget on deep code-mapping before edits — make the changes, then explain. Use small targeted greps, not long scrollthroughs.

---

## When to start a new Claude session

Start a **new session** when:
- The conversation is getting very long and Claude starts losing context
- A full batch is complete and shipped (natural stopping point)
- You've done 3+ batches in one session
- Claude hits tool budget limits mid-batch (don't push — start fresh)

---

## State of play — what shipped most recently

### ✅ This session (Batch-bridge between Batch 5 and Batch 6) — confirmed shipped
- **#217-fix** Relationship form layout — Char A is now full-width on top, Char B full-width below (no longer side-by-side). Both fields confirmed to start blank on new entries.
- **#239 / #272** Quick-relationships character picker is now searchable (search-as-you-type with dropdown). + New now creates the character using whatever the user typed in the search box (or prompts if empty), and selects it in that row.
- **#245 + #268** Empty-state message rewrite — when the suggest feature finds nothing, the alert now explains exactly what relationships need to exist for suggestions to appear (Mother/Father/Sibling for family, Employer/Teacher for colleagues/students, same-last-name + shared connection for the surname check). The underlying detection logic was already in place — most "not working" reports trace to no source data being available yet.
- **#271** Edit-type-change fail-safe — when editing an existing entry, changing the type dropdown now shows a confirmation describing what's saved ("You're EDITING an existing Character entry: 'Lila'. Changing the type to Quote will convert this entry…") with Continue / Cancel.
- **#273** In-app bug tracker — new "🧪 Log a test result" panel inside the Report sheet. Type a ticket #, optional note, tap ✅ or ⚠️. Copy-all output now splits cleanly into TEST RESULTS and NEW REQUESTS sections with explicit instructions to Claude on how to handle each.

### ⚠️ Family-suggestions label question — UNRESOLVED
User reported the family-suggestions UI hasn't been renamed to "Suggest relationships." A grep across the file shows all 🧬 button labels and the sheet title already say "Suggest relationships" / "Suggested relationships." The only remaining "Family" labels are filter-chip categories on the Rel. Web view (All / Main chars / **Family** / Romantic / Social…) — those are deliberate filter categories, not the suggest feature, and should stay.
- **First thing next session:** ask the user where exactly they're seeing the un-renamed label (a screenshot or quoted text). Possibilities: cached PWA, different label phrase Claude hasn't found, or the user is referring to the filter chip.

### ✅ Batch 5 — confirmed shipped (still needs testing)
- **#218 / #218-A / #218-B / #231** Timeline offset block — collapsed behind "Related to another event?" checkbox; renamed; direction dropdown reads "+ later (below)" / "− earlier (above)" with inline help text; Edit re-opens toggle and restores values
- **#218-C** Inline "+ insert here" between every adjacent pair of timeline entries
- **#187-A** Theme post-save now actually applies the Theme filter chip on the Log tab
- **#191-A** Saving a Theme auto-tags supporting-quote speakers into "Characters Involved"
- **#267 + #269** Character profile combines Events + Timeline into one "Character timeline" section
- **#270** New "Sequence #" field on Timeline form

### ✅ Batch 4 — confirmed shipped
- **#216** ✅ confirmed working
- **#217** ⚠️ first attempt didn't fully resolve — re-fix shipped this session
- **#239** ⚠️ first attempt didn't fully resolve — re-fix shipped this session
- **#244** ✅ confirmed working
- **#245** ⚠️ logic was correct; empty-state message rewritten this session
- **#268** ⚠️ logic was correct; empty-state message rewritten this session

### ✅ Batch 3 — confirmed shipped + tested
- **#260, #261, #262, #262-fix, #263, #264, #265** all ✅ confirmed working

---

## Suggested batch order going forward

### Batch 6 — Page/chapter UX *(next up — already mapped from prior session)*
- **#219** Rename "Page range" → "pg(s)" everywhere; pg(s) left, chapter right
- **#220** Character form: "Introduced p." sync with chapter setup
- **#221** Characteristic: "Quote pg(s)" / "Quote ch" sync
- **#222** Chapter entry: auto-fill next chapter start page
- **#222-A** Warn if chapter number is skipped
- **#249** Page range vs Quote page range labels + tooltips
- **#253** Timeline: supporting quote + speaker auto-tag *(deferred from Batch 5)*

### Batch 7 — Entry form quality of life
- **#237** Theme quick-add character + auto-tag in involved
- **#238** Audit: quick-add character auto-tags everywhere
- **#240** + FAB on character & location profile screens *(absorbs #266)*
- **#241** Auto pre-fill current character on profile-FAB
- **#243** "Themes" as own category on character profile
- **#247** Characteristic speaker field + auto-tag
- **#248** Quick characteristic dropdown on Character entry
- **#250** Discard draft button
- **#251** Background field on Character entry

### Batch 8 — Quotes / themes
- **#242** Theme embedded quotes show on Quotes tab
- **#229** Bigger `"` on Quotes-tab cards

### Batch 9 — Bigger features (multi-session)
- **#225** Question entry rework
- **#226** + **#252** Searchable event-type picker
- **#246** Searchable relationship-type bar
- **#227** + **#227-A** + **#227-B** MW full definition + etymology
- **#228** + **#228-A** + **#228-B** Reference improvements
- **#99-B** Reference "actual time to read" + Stats reference section
- **#105-A-v2** PDF: vocab word photos
- **#192** Vocab speaker badge + Vocabulary section on character profile
- **#236** Slide-to-delete on book/entry cards
- **#188** (deleted) badge on surviving entries

### Batch 10 — Chapters tab (discuss first)
- **#223** Chapter entry: embedded Questions section
- **#223-A** Questions inline on chapter profile pages
- **#224** Chapters tab + per-chapter profile pages

### Batch 11 — Workflow / cleanup
- **#254** Reading-by-hand symbol cheat sheet (in-app)
- **#255** OCR / scan page
- **#256** Auto-generate next-session opener
- **#259** Reading-without-marking best practices doc
- **#257** Code cleanup pass
- **#258** UI / performance review
- **#121-C** Move My Maps trigger to Locations page
- **#230** Sub-locations discussion

---

## Session-end deliverables
1. Updated `index.html` in outputs
2. Updated `feature_tracker_updated.xlsx` in outputs (only when batch is fully complete)
3. Updated `NEXT_SESSION_OPENER.md` in outputs
4. `TESTING_[DATE].md` checklist for what to test
